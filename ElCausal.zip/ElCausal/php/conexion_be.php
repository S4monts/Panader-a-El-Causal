<?php


$conexion = mysqli_connect("localhost", "root", "", "login_panaderia_db");

/*
if($conexion){
    echo 'conectado con exito a la base de datos';
}else{
    echo 'No se pudo conectar a la base de datos';
}


*/
?>